package miniLeng;

public class RegistroExpr {
	public int			valorEnt;
	public boolean		valorBool;
	public boolean		expr_compuesta;
	public Simbolo		s;
	public String		valorString;
	public ASTNode		nodoAST;
	public Simbolo.ClaseParametro clase;
	public Simbolo.TipoVariable	tipoVar;
	public Simbolo.TipoSimbolo tipoSimb;
}
